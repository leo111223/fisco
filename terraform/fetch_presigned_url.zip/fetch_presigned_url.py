import boto3
import json

s3_client = boto3.client('s3')
BUCKET_NAME = 'leo-receipt'

def lambda_handler(event, context):
    headers = {
        'Access-Control-Allow-Origin': '*',  # Allow all origins
        'Access-Control-Allow-Methods': 'POST, OPTIONS',  # Changed to POST
        'Access-Control-Allow-Headers': '*',  # Allow all headers
        'Access-Control-Max-Age': '3600'
    }
    
    # Handle OPTIONS preflight request
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    # Verify it's a POST request
    if event.get('httpMethod') != 'POST':
        return {
            'statusCode': 405,
            'headers': headers,
            'body': json.dumps({
                'error': 'Method not allowed'
            })
        }
    
    try:
        # Generate the presigned URL
        presigned_url = s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': BUCKET_NAME,
                'Key': 'test.jpg',
                'ContentType': 'image/jpeg'
            },
            ExpiresIn=300
        )
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'uploadUrl': presigned_url
            })
        }
            
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e)
            })
        }

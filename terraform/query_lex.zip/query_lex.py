import boto3
import json
import os

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        # Using the correct table name with capital 'T'
        table = dynamodb.Table('Transactions')
        
        # Query recent transactions - modify this query based on your table structure
        response = table.scan(Limit=int(num_transactions))
        transactions = response.get('Items', [])
        
        if not transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions based on your data structure
            message_content = f"Here are your last {num_transactions} transactions:\n"
            for i, tx in enumerate(transactions, 1):
                # Modify this to match your transaction data structure
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                description = tx.get('description', 'Unknown merchant')
                message_content += f"{i}. {date}: ${amount} - {description}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        print("Returning Lex response:", json.dumps(response))
        return response
        
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", response)
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            })
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }
import boto3
import json
import os
import datetime
from boto3.dynamodb.conditions import Key
from decimal import Decimal

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name
        intent_name = event['sessionState']['intent']['name']
        print(f"Handling intent: {intent_name}")
        
        # Route to appropriate handler based on intent
        if intent_name == 'GetRecentTransactions':
            return handle_recent_transactions(event)
        elif intent_name == 'QuerySpendingByCategory':
            return handle_query_spending_by_category(event)
        else:
            # Default handler
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": intent_name,
                        "state": "Fulfilled"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"I'm not sure how to handle the {intent_name} intent yet."
                    }
                ]
            }
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_recent_transactions(event):
    """
    Handle the GetRecentTransactions intent
    """
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Scan the table to get all transactions
        response = table.scan()
        transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            transactions.extend(response.get('Items', []))
            
        print(f"Retrieved total of {len(transactions)} transactions")
        
        # Sort by date in descending order (newest first)
        sorted_transactions = sorted(
            transactions,
            key=lambda x: x.get('date', '0000-00-00'),
            reverse=True  # True for descending order (newest first)
        )
        
        # Take only the requested number
        latest_transactions = sorted_transactions[:int(num_transactions)]
        
        if not latest_transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions using your table's structure
            message_content = f"Here are your last {len(latest_transactions)} transactions:\n"
            for i, tx in enumerate(latest_transactions, 1):
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                merchant = tx.get('merchant_name', tx.get('name', 'Unknown merchant'))
                
                message_content += f"{i}. {date}: ${amount} - {merchant}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        return response
        
    except Exception as e:
        print(f"Error in handle_recent_transactions: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_query_spending_by_category(event):
    """
    Handle the QuerySpendingByCategory intent to return spending amounts for a specific category and time frame
    """
    try:
        # Add more detailed logging
        print("Full event for QuerySpendingByCategory:", json.dumps(event))
        
        # Helper function for category matching
        def is_category_match(search_category, tx_category, tx_merchant, tx_name):
            # Direct matching
            if search_category in tx_category or search_category in tx_merchant or search_category in tx_name:
                return True
                
            # Special case for dining
            if search_category == "dining" and ("restaurant" in tx_category or 
                                               "food" in tx_category or 
                                               "fast food" in tx_category):
                return True
                
            # Special case for groceries
            if search_category == "groceries" and ("supermarket" in tx_category or 
                                                  "food and drink" in tx_category or 
                                                  "grocery" in tx_merchant):
                return True
                
            # Special case for travel
            if search_category == "travel" and ("airline" in tx_category or 
                                              "hotel" in tx_category or 
                                              "vacation" in tx_merchant):
                return True
                
            return False
        
        slots = event['sessionState']['intent']['slots']
        print("Slots received:", json.dumps(slots))
        
        intent_name = event['sessionState']['intent']['name']
        print(f"Processing intent: {intent_name}")
        
        # Debug available slot keys
        slot_keys = list(slots.keys())
        print(f"Available slot keys: {slot_keys}")
        
        # Try different potential slot names
        potential_category_slots = ['Category', 'SpendingCategory']
        potential_timeframe_slots = ['TimeFrame', 'SpendingTimeFrame']
        
        category = None
        time_frame = None
        
        # Try each potential slot name
        for slot_name in potential_category_slots:
            if slots.get(slot_name) and slots[slot_name].get('value') and slots[slot_name]['value'].get('interpretedValue'):
                category = slots[slot_name]['value']['interpretedValue'].strip().lower()
                print(f"Found category value using slot name '{slot_name}': {category}")
                break
        
        for slot_name in potential_timeframe_slots:
            if slots.get(slot_name) and slots[slot_name].get('value') and slots[slot_name]['value'].get('interpretedValue'):
                time_frame = slots[slot_name]['value']['interpretedValue'].lower()
                print(f"Found time frame value using slot name '{slot_name}': {time_frame}")
                break
        
        if not category or not time_frame:
            missing_slot = "Category" if not category else "TimeFrame"
            print(f"Missing slot: {missing_slot}")
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "slotToElicit": missing_slot
                    },
                    "intent": {
                        "name": intent_name,
                        "slots": slots
                    }
                }
            }
        
        # Calculate date range based on time frame
        try:
            print(f"Calculating date range for time frame: {time_frame}")
            start_date, end_date = calculate_date_range(time_frame)
            print(f"Date range calculated: {start_date} to {end_date}")
        except Exception as date_error:
            print(f"Error calculating date range: {str(date_error)}")
            import traceback
            print(f"Date range traceback: {traceback.format_exc()}")
            raise
        
        # Query DynamoDB for transactions
        try:
            dynamodb = boto3.resource('dynamodb')
            table = dynamodb.Table('Transactions')
            
            # Get all transactions
            response = table.scan()
            all_transactions = response.get('Items', [])
            
            # Continue scanning if we have more items (pagination)
            while 'LastEvaluatedKey' in response:
                response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                all_transactions.extend(response.get('Items', []))
            
            print(f"Retrieved {len(all_transactions)} transactions from DynamoDB")
            
            # Print a sample transaction
            if len(all_transactions) > 0:
                print(f"Sample transaction structure: {json.dumps(all_transactions[0], cls=DecimalEncoder)}")
        except Exception as db_error:
            print(f"Error retrieving transactions from DynamoDB: {str(db_error)}")
            import traceback
            print(f"DynamoDB traceback: {traceback.format_exc()}")
            raise
        
        # Improved filtering with better debugging and error handling
        try:
            print(f"Filtering transactions for category '{category}' between {start_date} and {end_date}")
            
            filtered_transactions = []
            for tx in all_transactions:
                tx_category = str(tx.get('category', '')).lower()
                tx_merchant = str(tx.get('merchant_name', '')).lower()
                tx_name = str(tx.get('name', '')).lower()
                tx_date = tx.get('date', '0000-00-00')
                
                # Debug a few transactions
                if len(filtered_transactions) < 2:
                    print(f"Checking transaction - Category: {tx_category}, Merchant: {tx_merchant}, Date: {tx_date}")
                
                # Use the new category matching function
                category_match = is_category_match(category, tx_category, tx_merchant, tx_name)
                date_match = (start_date <= tx_date <= end_date)
                
                if category_match and date_match:
                    # Clean amount value for proper calculation
                    amount_str = str(tx.get('amount', '0'))
                    # Remove currency symbols and commas
                    amount_str = amount_str.replace('$', '').replace(',', '')
                    try:
                        amount_val = float(amount_str)
                        tx['cleaned_amount'] = amount_val
                        filtered_transactions.append(tx)
                        print(f"Added matching transaction: {tx_date}, {amount_str}")
                    except ValueError:
                        print(f"Could not parse amount value: {amount_str}")
            
            print(f"Found {len(filtered_transactions)} transactions matching category and date range")
            if filtered_transactions:
                print(f"First matching transaction: {json.dumps(filtered_transactions[0], cls=DecimalEncoder)}")
        except Exception as filter_error:
            print(f"Error filtering transactions: {str(filter_error)}")
            import traceback
            print(f"Filtering traceback: {traceback.format_exc()}")
            raise
        
        # Calculate total spending in this category
        try:
            total_spent = sum(tx.get('cleaned_amount', 0) for tx in filtered_transactions)
            print(f"Total spending calculated: ${total_spent:.2f}")
        except Exception as sum_error:
            print(f"Error calculating total: {str(sum_error)}")
            import traceback
            print(f"Sum calculation traceback: {traceback.format_exc()}")
            raise
        
        # Format the response
        try:
            if filtered_transactions:
                message = f"You spent ${total_spent:.2f} on {category} {time_frame}. "
                
                # Add some details about largest transactions if available
                if len(filtered_transactions) > 0:
                    # Sort by amount (largest first)
                    sorted_tx = sorted(filtered_transactions, key=lambda x: x.get('cleaned_amount', 0), reverse=True)
                    largest_tx = sorted_tx[0]
                    largest_amount = largest_tx.get('cleaned_amount', 0)
                    largest_merchant = largest_tx.get('merchant_name', largest_tx.get('name', 'Unknown merchant'))
                    message += f"Your largest {category} expense was ${largest_amount:.2f} at {largest_merchant}."
            else:
                message = f"You had no {category} expenses {time_frame}. 🎉"
            
            print(f"Generated response message: {message}")
        except Exception as msg_error:
            print(f"Error generating response message: {str(msg_error)}")
            import traceback
            print(f"Message generation traceback: {traceback.format_exc()}")
            raise
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message
                }
            ]
        }
        
    except Exception as e:
        print(f"Error processing spending query: {str(e)}")
        print(f"Exception type: {type(e)}")
        print(f"Exception args: {e.args}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I had trouble calculating your spending. Please try again later."
                }
            ]
        }

def calculate_date_range(time_frame):
    """
    Calculate start and end dates based on a time frame description
    """
    today = datetime.datetime.now().date()
    print(f"Current date: {today.isoformat()}")
    
    if time_frame in ['today', 'this day']:
        print("Matched time frame: today/this day")
        return today.isoformat(), today.isoformat()
    
    elif time_frame == 'yesterday':
        print("Matched time frame: yesterday")
        yesterday = today - datetime.timedelta(days=1)
        return yesterday.isoformat(), yesterday.isoformat()
    
    elif time_frame in ['this week', 'current week']:
        print("Matched time frame: this week/current week")
        start_of_week = today - datetime.timedelta(days=today.weekday())
        return start_of_week.isoformat(), today.isoformat()
    
    elif time_frame in ['last week', 'previous week']:
        print("Matched time frame: last week/previous week")
        end_of_last_week = today - datetime.timedelta(days=today.weekday() + 1)
        start_of_last_week = end_of_last_week - datetime.timedelta(days=6)
        return start_of_last_week.isoformat(), end_of_last_week.isoformat()
    
    elif time_frame in ['this month', 'current month']:
        print("Matched time frame: this month/current month")
        start_of_month = today.replace(day=1)
        return start_of_month.isoformat(), today.isoformat()
    
    elif time_frame in ['last month', 'previous month']:
        print("Matched time frame: last month/previous month")
        end_of_last_month = today.replace(day=1) - datetime.timedelta(days=1)
        start_of_last_month = end_of_last_month.replace(day=1)
        return start_of_last_month.isoformat(), end_of_last_month.isoformat()
    
    elif time_frame in ['this year', 'current year']:
        print("Matched time frame: this year/current year")
        start_of_year = today.replace(month=1, day=1)
        return start_of_year.isoformat(), today.isoformat()
    
    elif time_frame in ['last year', 'previous year']:
        print("Matched time frame: last year/previous year")
        last_year = today.year - 1
        start_of_last_year = today.replace(year=last_year, month=1, day=1)
        end_of_last_year = today.replace(year=last_year, month=12, day=31)
        return start_of_last_year.isoformat(), end_of_last_year.isoformat()
    
    # Default: assume recent (last 30 days)
    print(f"No specific match for time frame '{time_frame}', using default (last 30 days)")
    default_start = today - datetime.timedelta(days=30)
    return default_start.isoformat(), today.isoformat()

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", json.dumps(response, cls=DecimalEncoder))
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            }, cls=DecimalEncoder)
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }
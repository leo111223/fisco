import boto3
import json
import os
from boto3.dynamodb.conditions import Key
from decimal import Decimal

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Scan the table to get all transactions
        response = table.scan()
        transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            transactions.extend(response.get('Items', []))
            
        print(f"Retrieved total of {len(transactions)} transactions")
        
        # Sort by date in descending order (newest first)
        sorted_transactions = sorted(
            transactions,
            key=lambda x: x.get('date', '0000-00-00'),
            reverse=True  # True for descending order (newest first)
        )
        
        # Take only the requested number
        latest_transactions = sorted_transactions[:int(num_transactions)]
        
        if not latest_transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions using your table's structure
            message_content = f"Here are your last {len(latest_transactions)} transactions:\n"
            for i, tx in enumerate(latest_transactions, 1):
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                merchant = tx.get('merchant_name', tx.get('name', 'Unknown merchant'))
                
                message_content += f"{i}. {date}: ${amount} - {merchant}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        return response
        
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", json.dumps(response, cls=DecimalEncoder))
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            }, cls=DecimalEncoder)
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }
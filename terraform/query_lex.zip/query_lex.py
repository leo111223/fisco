import boto3
import json
import os
import datetime
from boto3.dynamodb.conditions import Key
from decimal import Decimal

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name
        intent_name = event['sessionState']['intent']['name']
        print(f"Handling intent: {intent_name}")
        
        # Route to appropriate handler based on intent
        if intent_name == 'GetRecentTransactions':
            return handle_recent_transactions(event)
        elif intent_name == 'QuerySpendingByCategory':
            return handle_query_spending_by_category(event)
        else:
            # Default handler
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": intent_name,
                        "state": "Fulfilled"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"I'm not sure how to handle the {intent_name} intent yet."
                    }
                ]
            }
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_recent_transactions(event):
    """
    Handle the GetRecentTransactions intent
    """
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Scan the table to get all transactions
        response = table.scan()
        transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            transactions.extend(response.get('Items', []))
            
        print(f"Retrieved total of {len(transactions)} transactions")
        
        # Sort by date in descending order (newest first)
        sorted_transactions = sorted(
            transactions,
            key=lambda x: x.get('date', '0000-00-00'),
            reverse=True  # True for descending order (newest first)
        )
        
        # Take only the requested number
        latest_transactions = sorted_transactions[:int(num_transactions)]
        
        if not latest_transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions using your table's structure
            message_content = f"Here are your last {len(latest_transactions)} transactions:\n"
            for i, tx in enumerate(latest_transactions, 1):
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                merchant = tx.get('merchant_name', tx.get('name', 'Unknown merchant'))
                
                message_content += f"{i}. {date}: ${amount} - {merchant}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        return response
        
    except Exception as e:
        print(f"Error in handle_recent_transactions: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_query_spending_by_category(event):
    """
    Handle the QuerySpendingByCategory intent to return spending amounts for a specific category and time frame
    """
    try:
        # Helper function for category matching that only uses the category field
        def is_category_match(search_category, tx_category):
            # Handle null or empty categories
            if not tx_category or tx_category == 'null':
                return False
                
            # Convert search_category to lowercase for case-insensitive matching
            search_category = search_category.lower()
            
            # Convert the category string to lowercase for easier matching
            tx_category_lower = str(tx_category).lower()
            
            # Simple keyword matching approach
            if search_category == "travel":
                travel_keywords = ["travel", "airline", "aviation", "flight", "hotel"]
                for keyword in travel_keywords:
                    if keyword in tx_category_lower:
                        return True
            
            elif search_category == "dining":
                dining_keywords = ["restaurant", "food", "dining", "coffee", "fast food"]
                for keyword in dining_keywords:
                    if keyword in tx_category_lower:
                        return True
            
            elif search_category == "transportation":
                transport_keywords = ["taxi", "uber", "lyft", "bus", "train", "metro", "subway"]
                for keyword in transport_keywords:
                    if keyword in tx_category_lower:
                        return True
            
            elif search_category == "groceries":
                grocery_keywords = ["supermarket", "grocery"]
                for keyword in grocery_keywords:
                    if keyword in tx_category_lower:
                        return True
                        
            elif search_category == "entertainment":
                entertainment_keywords = ["entertainment", "movie", "theater", "cinema", "concert", 
                                       "recreation", "gym", "fitness", "sporting"]
                for keyword in entertainment_keywords:
                    if keyword in tx_category_lower:
                        return True
            
            # If no specific category match, check if the search category appears directly
            return search_category in tx_category_lower
        
        # Extract slots from event
        slots = event['sessionState']['intent']['slots']
        intent_name = event['sessionState']['intent']['name']
        
        # Try different potential slot names
        potential_category_slots = ['Category', 'SpendingCategory']
        potential_timeframe_slots = ['TimeFrame', 'SpendingTimeFrame']
        
        category = None
        time_frame = None
        
        # Try each potential slot name
        for slot_name in potential_category_slots:
            if slots.get(slot_name) and slots[slot_name].get('value') and slots[slot_name]['value'].get('interpretedValue'):
                category = slots[slot_name]['value']['interpretedValue'].strip().lower()
                break
        
        for slot_name in potential_timeframe_slots:
            if slots.get(slot_name) and slots[slot_name].get('value') and slots[slot_name]['value'].get('interpretedValue'):
                time_frame = slots[slot_name]['value']['interpretedValue'].lower()
                break
        
        if not category or not time_frame:
            missing_slot = "Category" if not category else "TimeFrame"
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "slotToElicit": missing_slot
                    },
                    "intent": {
                        "name": intent_name,
                        "slots": slots
                    }
                }
            }
        
        # Calculate date range based on time frame
        start_date, end_date = calculate_date_range(time_frame)
        
        # Query DynamoDB for transactions
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Get all transactions
        response = table.scan()
        all_transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            all_transactions.extend(response.get('Items', []))
        
        # SIMPLIFIED APPROACH: Two-pass processing
        # First pass: Find all matching transactions and store amount and name for each
        matching_txs = []
        
        for tx in all_transactions:
            tx_category = tx.get('category', '')
            tx_date = tx.get('date', '0000-00-00')
            
            # Only process if both category and date match
            if is_category_match(category, tx_category) and (start_date <= tx_date <= end_date):
                tx_amount = tx.get('amount', '0')
                tx_name = tx.get('name', 'Unknown merchant')
                
                # Standardize the amount to a float
                amount_float = 0.0
                
                # Handle different types of amount data
                if isinstance(tx_amount, (int, float)):
                    amount_float = float(tx_amount)
                elif isinstance(tx_amount, str):
                    # Clean the string amount
                    clean_amount = tx_amount.replace('$', '').replace(',', '').strip()
                    try:
                        amount_float = float(clean_amount)
                    except:
                        # Skip if we can't parse it
                        continue
                else:
                    # For Decimal objects from DynamoDB
                    try:
                        amount_float = float(tx_amount)
                    except:
                        continue
                
                # Skip zero or negative amounts
                if amount_float <= 0:
                    continue
                    
                # Add to our matching transactions list
                matching_txs.append({
                    'name': tx_name,
                    'amount': amount_float
                })
        
        # If no matching transactions were found
        if not matching_txs:
            message = f"You had no {category} expenses {time_frame}."
        else:
            # Find total and largest transaction
            total_amount = 0.0
            largest_tx = None
            largest_amount = 0.0
            
            for tx in matching_txs:
                amount = tx['amount']
                total_amount += amount
                
                if amount > largest_amount:
                    largest_amount = amount
                    largest_tx = tx
            
            # Format the response message
            message = f"You spent ${total_amount:.2f} on {category} {time_frame}."
            
            # Only add largest transaction details if there are multiple transactions
            if len(matching_txs) > 1 and largest_tx:
                message += f" Your largest {category} expense was ${largest_amount:.2f} at {largest_tx['name']}."
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message
                }
            ]
        }
        
    except Exception as e:
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "I'm sorry, I had trouble calculating your spending. Please try again later."
                }
            ]
        }

def calculate_date_range(time_frame):
    """
    Calculate start and end dates based on a time frame description
    """
    today = datetime.datetime.now().date()
    print(f"Current date: {today.isoformat()}")
    
    # Standardize the time_frame
    time_frame = time_frame.lower().strip()
    
    # Handle simple cases directly
    if time_frame in ['today', 'this day']:
        print("Matched time frame: today/this day")
        return today.isoformat(), today.isoformat()
    
    elif time_frame in ['yesterday']:
        print("Matched time frame: yesterday")
        yesterday = today - datetime.timedelta(days=1)
        return yesterday.isoformat(), yesterday.isoformat()
    
    elif time_frame in ['this week', 'current week']:
        print("Matched time frame: this week/current week")
        start_of_week = today - datetime.timedelta(days=today.weekday())
        return start_of_week.isoformat(), today.isoformat()
    
    elif time_frame in ['last week', 'previous week']:
        print("Matched time frame: last week/previous week")
        end_of_last_week = today - datetime.timedelta(days=today.weekday() + 1)
        start_of_last_week = end_of_last_week - datetime.timedelta(days=6)
        return start_of_last_week.isoformat(), end_of_last_week.isoformat()
    
    elif time_frame in ['this month', 'current month']:
        print("Matched time frame: this month/current month")
        start_of_month = today.replace(day=1)
        return start_of_month.isoformat(), today.isoformat()
    
    elif time_frame in ['last month', 'previous month']:
        print("Matched time frame: last month/previous month")
        # If we're in the first month of the year, we need to go back to previous year
        if today.month == 1:
            start_of_last_month = datetime.date(today.year - 1, 12, 1)
            end_of_last_month = datetime.date(today.year - 1, 12, 31)
        else:
            end_of_last_month = today.replace(day=1) - datetime.timedelta(days=1)
            start_of_last_month = end_of_last_month.replace(day=1)
        return start_of_last_month.isoformat(), end_of_last_month.isoformat()
    
    elif time_frame in ['this year', 'current year']:
        print("Matched time frame: this year/current year")
        start_of_year = today.replace(month=1, day=1)
        return start_of_year.isoformat(), today.isoformat()
    
    elif time_frame in ['last year', 'previous year']:
        print("Matched time frame: last year/previous year")
        last_year = today.year - 1
        start_of_last_year = datetime.date(last_year, 1, 1)
        end_of_last_year = datetime.date(last_year, 12, 31)
        return start_of_last_year.isoformat(), end_of_last_year.isoformat()
    
    # Handle quarters
    elif time_frame in ['this quarter', 'current quarter']:
        print("Matched time frame: this quarter/current quarter")
        current_quarter = (today.month - 1) // 3 + 1
        start_month = (current_quarter - 1) * 3 + 1
        start_of_quarter = today.replace(month=start_month, day=1)
        return start_of_quarter.isoformat(), today.isoformat()
    
    elif time_frame in ['last quarter', 'previous quarter']:
        print("Matched time frame: last quarter/previous quarter")
        current_quarter = (today.month - 1) // 3 + 1
        previous_quarter = current_quarter - 1 if current_quarter > 1 else 4
        previous_quarter_year = today.year if current_quarter > 1 else today.year - 1
        
        # Calculate first month of the previous quarter
        start_month = (previous_quarter - 1) * 3 + 1
        start_of_quarter = datetime.date(previous_quarter_year, start_month, 1)
        
        # Calculate last day of the previous quarter
        if previous_quarter < 4:
            end_month = previous_quarter * 3
            # Last day of the month logic
            if end_month in [4, 6, 9, 11]:
                last_day = 30
            elif end_month == 2:
                # Check for leap year
                if (previous_quarter_year % 4 == 0 and previous_quarter_year % 100 != 0) or (previous_quarter_year % 400 == 0):
                    last_day = 29
                else:
                    last_day = 28
            else:
                last_day = 31
            
            end_of_quarter = datetime.date(previous_quarter_year, end_month, last_day)
        else:
            # Quarter 4 ends on December 31
            end_of_quarter = datetime.date(previous_quarter_year, 12, 31)
        
        return start_of_quarter.isoformat(), end_of_quarter.isoformat()
    
    # Handle "last X days/weeks/months" pattern
    elif time_frame.startswith('last ') and len(time_frame.split()) >= 2:
        parts = time_frame.split()
        try:
            # Try to extract a number
            num = int(parts[1])
            
            # Check what unit follows the number
            if len(parts) >= 3:
                unit = parts[2].lower()
                
                if unit.startswith('day'):
                    print(f"Matched time frame: last {num} days")
                    start_date = today - datetime.timedelta(days=num)
                    return start_date.isoformat(), today.isoformat()
                
                elif unit.startswith('week'):
                    print(f"Matched time frame: last {num} weeks")
                    start_date = today - datetime.timedelta(weeks=num)
                    return start_date.isoformat(), today.isoformat()
                
                elif unit.startswith('month'):
                    print(f"Matched time frame: last {num} months")
                    # Calculate months back (this is approximate)
                    year = today.year
                    month = today.month - num
                    
                    # Adjust if we need to go back in years
                    while month <= 0:
                        year -= 1
                        month += 12
                    
                    start_date = datetime.date(year, month, 1)
                    return start_date.isoformat(), today.isoformat()
            
        except (ValueError, IndexError):
            # If we can't parse the pattern, fall through to default
            pass
    
    # Default: assume recent (last 30 days)
    print(f"No specific match for time frame '{time_frame}', using default (last 30 days)")
    default_start = today - datetime.timedelta(days=30)
    return default_start.isoformat(), today.isoformat()

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", json.dumps(response, cls=DecimalEncoder))
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            }, cls=DecimalEncoder)
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }
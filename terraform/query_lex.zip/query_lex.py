import boto3
import json
import os
import datetime
from boto3.dynamodb.conditions import Key
from decimal import Decimal

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    
    # Check if this is a direct invocation from Lex
    if 'sessionState' in event:
        return handle_lex_invocation(event, context)
    # Otherwise, assume it's coming from API Gateway
    else:
        return handle_api_gateway_request(event, context)

def handle_lex_invocation(event, context):
    try:
        # Extract intent name
        intent_name = event['sessionState']['intent']['name']
        
        # Route to appropriate handler based on intent
        if intent_name == 'GetRecentTransactions':
            return handle_recent_transactions(event)
        elif intent_name == 'QuerySpendingByCategory':
            return handle_query_spending_by_category(event)
        else:
            # Default handler
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": intent_name,
                        "state": "Fulfilled"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"I'm not sure how to handle the {intent_name} intent yet."
                    }
                ]
            }
    except Exception as e:
        print(f"Error in Lex invocation: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_recent_transactions(event):
    """
    Handle the GetRecentTransactions intent
    """
    try:
        # Extract intent name and slot information
        intent_name = event['sessionState']['intent']['name']
        slots = event['sessionState']['intent'].get('slots', {})
        
        # Get the number of transactions requested
        num_transactions = 5  # Default value
        if slots and slots.get('NumberOfTransactions') and slots['NumberOfTransactions'].get('value'):
            num_transactions = slots['NumberOfTransactions']['value']['interpretedValue']
        
        # Get transactions from DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Scan the table to get all transactions
        response = table.scan()
        transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            transactions.extend(response.get('Items', []))
            
        print(f"Retrieved total of {len(transactions)} transactions")
        
        # Sort by date in descending order (newest first)
        sorted_transactions = sorted(
            transactions,
            key=lambda x: x.get('date', '0000-00-00'),
            reverse=True  # True for descending order (newest first)
        )
        
        # Take only the requested number
        latest_transactions = sorted_transactions[:int(num_transactions)]
        
        if not latest_transactions:
            message_content = f"I couldn't find any recent transactions in your account."
        else:
            # Format transactions using your table's structure
            message_content = f"Here are your last {len(latest_transactions)} transactions:\n"
            for i, tx in enumerate(latest_transactions, 1):
                date = tx.get('date', 'Unknown date')
                amount = tx.get('amount', 'Unknown amount')
                merchant = tx.get('merchant_name', tx.get('name', 'Unknown merchant'))
                
                message_content += f"{i}. {date}: ${amount} - {merchant}\n"
        
        # Build Lex response
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message_content
                }
            ]
        }
        
        return response
        
    except Exception as e:
        print(f"Error in handle_recent_transactions: {str(e)}")
        # Return a properly formatted Lex response even for errors
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I encountered an error: {str(e)}"
                }
            ]
        }

def handle_query_spending_by_category(event):
    """
    Handle the QuerySpendingByCategory intent to return spending amounts for a specific category and time frame
    """
    try:
        slots = event['sessionState']['intent']['slots']
        intent_name = event['sessionState']['intent']['name']
        
        # Get the category and time frame from slots
        category = slots.get('Category', {}).get('value', {}).get('interpretedValue', '').lower() if slots.get('Category') else None
        time_frame = slots.get('TimeFrame', {}).get('value', {}).get('interpretedValue', '').lower() if slots.get('TimeFrame') else None
        
        if not category or not time_frame:
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "slotToElicit": "Category" if not category else "TimeFrame"
                    },
                    "intent": {
                        "name": intent_name,
                        "slots": slots
                    }
                }
            }
        
        # Calculate date range based on time frame
        start_date, end_date = calculate_date_range(time_frame)
        
        # Query DynamoDB for transactions in this category within the date range
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Transactions')
        
        # Get all transactions (could be optimized with a GSI or query if available)
        response = table.scan()
        all_transactions = response.get('Items', [])
        
        # Continue scanning if we have more items (pagination)
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            all_transactions.extend(response.get('Items', []))
        
        # Filter transactions by category and date range
        # Adjust these filters based on your actual transaction data structure
        filtered_transactions = [
            tx for tx in all_transactions 
            if (tx.get('category', '').lower() == category or 
                category in tx.get('category', '').lower() or 
                category in tx.get('merchant_name', '').lower() or
                category in tx.get('name', '').lower()) and
               start_date <= tx.get('date', '0000-00-00') <= end_date
        ]
        
        # Calculate total spending in this category
        total_spent = sum(float(tx.get('amount', 0)) for tx in filtered_transactions)
        
        # Format the response
        if filtered_transactions:
            message = f"You spent ${total_spent:.2f} on {category} {time_frame}. "
            
            # Add some details about largest transactions if available
            if len(filtered_transactions) > 0:
                # Sort by amount (largest first)
                sorted_tx = sorted(filtered_transactions, key=lambda x: float(x.get('amount', 0)), reverse=True)
                largest_tx = sorted_tx[0]
                message += f"Your largest {category} expense was ${float(largest_tx.get('amount', 0)):.2f} at {largest_tx.get('merchant_name', largest_tx.get('name', 'Unknown merchant'))}."
        else:
            message = f"I couldn't find any {category} expenses {time_frame}."
        
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent_name,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": message
                }
            ]
        }
        
    except Exception as e:
        print(f"Error processing spending query: {str(e)}")
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": event['sessionState']['intent']['name'],
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": f"I'm sorry, I had trouble calculating your {category} spending. Please try again later."
                }
            ]
        }

def calculate_date_range(time_frame):
    """
    Calculate start and end dates based on a time frame description
    """
    today = datetime.datetime.now().date()
    
    if time_frame in ['today', 'this day']:
        return today.isoformat(), today.isoformat()
    
    elif time_frame == 'yesterday':
        yesterday = today - datetime.timedelta(days=1)
        return yesterday.isoformat(), yesterday.isoformat()
    
    elif time_frame in ['this week', 'current week']:
        start_of_week = today - datetime.timedelta(days=today.weekday())
        return start_of_week.isoformat(), today.isoformat()
    
    elif time_frame in ['last week', 'previous week']:
        end_of_last_week = today - datetime.timedelta(days=today.weekday() + 1)
        start_of_last_week = end_of_last_week - datetime.timedelta(days=6)
        return start_of_last_week.isoformat(), end_of_last_week.isoformat()
    
    elif time_frame in ['this month', 'current month']:
        start_of_month = today.replace(day=1)
        return start_of_month.isoformat(), today.isoformat()
    
    elif time_frame in ['last month', 'previous month']:
        end_of_last_month = today.replace(day=1) - datetime.timedelta(days=1)
        start_of_last_month = end_of_last_month.replace(day=1)
        return start_of_last_month.isoformat(), end_of_last_month.isoformat()
    
    elif time_frame in ['this year', 'current year']:
        start_of_year = today.replace(month=1, day=1)
        return start_of_year.isoformat(), today.isoformat()
    
    elif time_frame in ['last year', 'previous year']:
        last_year = today.year - 1
        start_of_last_year = today.replace(year=last_year, month=1, day=1)
        end_of_last_year = today.replace(year=last_year, month=12, day=31)
        return start_of_last_year.isoformat(), end_of_last_year.isoformat()
    
    # Default: assume recent (last 30 days)
    default_start = today - datetime.timedelta(days=30)
    return default_start.isoformat(), today.isoformat()

def handle_api_gateway_request(event, context):
    lex_client = boto3.client('lexv2-runtime')
    
    try:
        # Parse the body from the event
        body = json.loads(event.get('body', '{}'))
        user_message = body.get('message', '')
        
        if not user_message:
            raise ValueError("No message provided in the request body.")
        
        # Extract user ID from the request context (if available)
        user_id = event.get('requestContext', {}).get('authorizer', {}).get('claims', {}).get('sub', 'anonymous')
        
        # Call Lex to get a response based on the user input
        response = lex_client.recognize_text(
            botId=os.environ['LEX_BOT_ID'],
            botAliasId=os.environ['LEX_BOT_ALIAS_ID'],
            localeId='en_US',
            sessionId=user_id,
            text=user_message
        )
        
        # Add logs for Lex response
        print("Lex response:", json.dumps(response, cls=DecimalEncoder))
        
        # Ensure the 'messages' field exists before accessing it
        messages = response.get('messages', [])
        if messages:
            bot_response = messages[0].get('content', "I'm sorry, I couldn't process that request.")
        else:
            bot_response = "I'm sorry, I couldn't process that request."
        
        # Return the processed response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': bot_response,
                'sessionState': response.get('sessionState', {}),
                'requestAttributes': response.get('requestAttributes', {})
            }, cls=DecimalEncoder)
        }
        
    except ValueError as ve:
        print(f"ValueError: {str(ve)}")
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Bad request: {str(ve)}"
            })
        }
    
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': f"Internal server error: {str(e)}"
            })
        }
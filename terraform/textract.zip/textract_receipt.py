import json
import boto3
import uuid
from decimal import Decimal
from datetime import datetime
from botocore.exceptions import ClientError
import os
# Initialize AWS clients
s3 = boto3.client('s3')
textract = boto3.client('textract')
bedrock = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')

# Constants
BUCKET_NAME = os.environ['BUCKET_NAME']
#BUCKET_NAME = 'leo-receipt'
BUCKET_KEY = 'test.jpg'
TRANSACTIONS_TABLE = 'Transactions'

def lambda_handler(event, context):
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Max-Age': '3600'
    }
    
    try:
        # Get the file from S3
        response = s3.get_object(Bucket=BUCKET_NAME, Key=BUCKET_KEY)
        file_content = response['Body'].read()

        # Call Textract to detect document text
        textract_response = textract.detect_document_text(
            Document={'Bytes': file_content}
        )

        # Extract detected text
        detected_text = ""
        for item in textract_response['Blocks']:
            if item['BlockType'] == 'LINE':
                detected_text += item['Text'] + '\n'

        # Use LLM to parse receipt text
        prompt = f"""
        Extract the following fields from this receipt into JSON:
        - date (format as YYYY-MM-DD)
        - name (payee name)
        - amount (total amount including tax)
        - category (e.g., Food, Dining)
        - iso_currency_code (infer if missing)
        Ignore missing fields. 
        
        Receipt:
        {detected_text}
        """
        
        bedrock_response = bedrock.invoke_model(
            modelId="anthropic.claude-3-sonnet-20240229-v1:0",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 200
            })
        )
        
        result = json.loads(bedrock_response['body'].read().decode('utf-8'))
        parsed_data = json.loads(result['content'][0]['text'])

        # Generate a unique transaction ID
        transaction_id = str(uuid.uuid4())

        # Get merchant name from the first line of the receipt
        merchant_name = detected_text.split('\n')[0].strip()

        # Create transaction item for DynamoDB
        # Note: Keys are now in correct order - transaction_id as partition key, user_id as sort key
        transaction_item = {
            'transaction_id': transaction_id,  # Partition key
            'user_id': 'default_user',        # Sort key
            'date': parsed_data['date'],
            'amount': Decimal(str(parsed_data['amount'])),
            'name': parsed_data['name'],
            'merchant_name': merchant_name,
            'category': [parsed_data['category']],
            'iso_currency_code': parsed_data.get('iso_currency_code', 'USD'),
            'payment_channel': 'in store',
            'pending': False,
            'transaction_type': 'place',
            'receipt_raw_text': detected_text,
            'created_at': datetime.now().isoformat(),
            'receipt_s3_key': BUCKET_KEY
        }

        # Write to DynamoDB
        table = dynamodb.Table(TRANSACTIONS_TABLE)
        table.put_item(Item=transaction_item)
        
        # Verify the write was successful
        verify_response = table.get_item(
            Key={
                'transaction_id': transaction_id,
                'user_id': 'default_user'
            }
        )
        
        if 'Item' not in verify_response:
            raise Exception("Transaction verification failed - item not found after write")
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'raw_text': detected_text,
                'parsed_data': parsed_data,
                'transaction_id': transaction_id,
                'message': 'Transaction saved successfully',
                'verification': 'Transaction verified in database'
            }, default=str)  # Handle Decimal serialization
        }

    except ClientError as e:
        print(f"AWS Service Error: {e.response['Error']['Message']}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': f"AWS Service Error: {e.response['Error']['Message']}"
            })
        }
    except Exception as e:
        print(f"Error processing file: {e}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e)
            })
        }

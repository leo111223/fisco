import json
import boto3
from decimal import Decimal
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

#lambda for fetching the latest data from the Transactions table (latest data)


# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'Transactions'

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Credentials': 'true'
    }
    
    # Handle OPTIONS request for CORS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({})
        }
    
    try:
        # Initialize DynamoDB table
        table = dynamodb.Table(TABLE_NAME)
        logger.info("Connected to DynamoDB table")
        
        # Simple scan to get all items
        response = table.scan()
        logger.info("Successfully scanned table")
        
        transactions = response.get('Items', [])
        logger.info(f"Found {len(transactions)} transactions")

        # Format response
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'transactions': transactions,
                'total_found': len(transactions),
                'status': 'success'
            }, cls=DecimalEncoder)
        }
            
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e),
                'error_type': type(e).__name__,
                'status': 'error'
            })
        }
